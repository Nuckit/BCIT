﻿/// <summary>
/// Summary description for Product
/// </summary>
public class Product
{
    public string Name { get; set; }
    public int Id { get; set; }
    public int UnitsInStock { get; set; }
    public decimal UnitPrice { get; set; }

	public Product()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}
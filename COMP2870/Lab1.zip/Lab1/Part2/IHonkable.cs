﻿namespace Part2
{
    public interface IHonkable
    {
        void Honk();
    }
}
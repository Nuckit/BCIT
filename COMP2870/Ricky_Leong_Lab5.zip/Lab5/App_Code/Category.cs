﻿/// <summary>
/// Summary description for Category
/// </summary>
public class Category
{
    public string Name { get; set; }
    public int Id { get; set; }
    public string Description { get; set; }

	public Category()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}